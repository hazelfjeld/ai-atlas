CREATE TABLE topics (name TEXT PRIMARY KEY, description TEXT NOT NULL);

CREATE TABLE terms (
 id TEXT PRIMARY KEY, term TEXT NOT NULL UNIQUE, definition TEXT NOT NULL,
 topic TEXT NOT NULL REFERENCES topics(name), level TEXT NOT NULL,
 example TEXT NOT NULL, caveat TEXT NOT NULL, reference_url TEXT NOT NULL,
 notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE aliases (
 term_id TEXT NOT NULL REFERENCES terms(id), alias TEXT NOT NULL,
 PRIMARY KEY(term_id,alias)
);

CREATE TABLE tags (
 name TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('field','workflow')),
 description TEXT NOT NULL, PRIMARY KEY(name,kind)
);

CREATE TABLE term_tags (
 term_id TEXT NOT NULL REFERENCES terms(id), tag_name TEXT NOT NULL,
 tag_kind TEXT NOT NULL, PRIMARY KEY(term_id,tag_name,tag_kind),
 FOREIGN KEY(tag_name,tag_kind) REFERENCES tags(name,kind)
);

CREATE TABLE sources (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, url TEXT NOT NULL,
 kind TEXT NOT NULL, review_status TEXT NOT NULL
);

CREATE TABLE term_sources (
 term_id TEXT NOT NULL REFERENCES terms(id), source_id TEXT NOT NULL REFERENCES sources(id),
 position INTEGER NOT NULL, PRIMARY KEY(term_id,source_id)
);

CREATE TABLE relationships (
 from_id TEXT NOT NULL REFERENCES terms(id), to_id TEXT NOT NULL REFERENCES terms(id),
 relation_type TEXT NOT NULL DEFAULT 'related',
 PRIMARY KEY(from_id,to_id,relation_type), CHECK(from_id<>to_id)
);

CREATE TABLE learning_paths (
 path TEXT NOT NULL, step INTEGER NOT NULL, term_id TEXT NOT NULL REFERENCES terms(id),
 rationale TEXT NOT NULL, PRIMARY KEY(path,step)
);

CREATE INDEX idx_terms_topic ON terms(topic);

CREATE INDEX idx_terms_level ON terms(level);

CREATE INDEX idx_tags_lookup ON term_tags(tag_name,tag_kind);

CREATE INDEX idx_alias_lookup ON aliases(alias COLLATE NOCASE);

CREATE INDEX idx_related_target ON relationships(to_id);

CREATE VIRTUAL TABLE terms_fts USING fts5(
 term_id UNINDEXED, term, aliases, definition, tags, workflow, topic, example, caveat,
 tokenize='unicode61'
);

CREATE TABLE technology_sections (
 id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE,
 fields_json TEXT NOT NULL, stages_json TEXT NOT NULL
);

CREATE TABLE technologies (
 id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE,
 section_id TEXT NOT NULL REFERENCES technology_sections(id),
 kind TEXT NOT NULL, what TEXT NOT NULL, edge TEXT NOT NULL,
 best_for TEXT NOT NULL, watch_out TEXT NOT NULL,
 runtime TEXT NOT NULL, access TEXT NOT NULL, execution TEXT NOT NULL,
 evidence_status TEXT NOT NULL, reviewed_on TEXT,
 lifecycle TEXT NOT NULL, comparison_basis TEXT NOT NULL,
 complexity TEXT NOT NULL, test_before_choice TEXT NOT NULL,
 notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE technology_sources (
 technology_id TEXT NOT NULL REFERENCES technologies(id),
 url TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'primary',
 review_status TEXT NOT NULL, reviewed_on TEXT,
 PRIMARY KEY(technology_id,url)
);

CREATE TABLE technology_tags (
 technology_id TEXT NOT NULL REFERENCES technologies(id),
 tag TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('field','workflow','keyword')),
 PRIMARY KEY(technology_id,tag,kind)
);

CREATE TABLE technology_concepts (
 technology_id TEXT NOT NULL REFERENCES technologies(id),
 term_id TEXT NOT NULL REFERENCES terms(id),
 PRIMARY KEY(technology_id,term_id)
);

CREATE TABLE technology_alternatives (
 technology_id TEXT NOT NULL REFERENCES technologies(id),
 alternative_name TEXT NOT NULL,
 alternative_id TEXT REFERENCES technologies(id),
 PRIMARY KEY(technology_id,alternative_name),
 CHECK(technology_id <> alternative_id)
);

CREATE TABLE playbooks (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, problem TEXT NOT NULL,
 rationale TEXT NOT NULL, first_step TEXT NOT NULL,
 validation TEXT NOT NULL, caveat TEXT NOT NULL, status TEXT NOT NULL
);

CREATE TABLE playbook_technologies (
 playbook_id TEXT NOT NULL REFERENCES playbooks(id),
 technology_id TEXT NOT NULL REFERENCES technologies(id),
 position INTEGER NOT NULL,
 PRIMARY KEY(playbook_id,technology_id)
);

CREATE TABLE playbook_tags (
 playbook_id TEXT NOT NULL REFERENCES playbooks(id),
 tag TEXT NOT NULL, PRIMARY KEY(playbook_id,tag)
);

CREATE INDEX idx_technology_section ON technologies(section_id);

CREATE INDEX idx_technology_tag ON technology_tags(tag,kind);

CREATE INDEX idx_technology_term ON technology_concepts(term_id);

CREATE VIEW technology_profiles AS
 SELECT t.*,s.name AS section,p.url AS primary_reference
 FROM technologies AS t
 JOIN technology_sections AS s ON s.id=t.section_id
 LEFT JOIN technology_sources AS p ON p.technology_id=t.id AND p.role='primary';

CREATE VIRTUAL TABLE technology_fts USING fts5(
 technology_id UNINDEXED, name, what, edge, best_for, watch_out, keywords,
 tokenize='unicode61 remove_diacritics 2'
);