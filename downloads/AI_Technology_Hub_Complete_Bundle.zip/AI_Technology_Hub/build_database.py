#!/usr/bin/env python3
"""Rebuild the hub SQLite snapshot from the included JSONL and dictionary database.
Uses Python's standard library. Run from any working directory with Python 3.10+.
This replaces ai_technology_hub.sqlite, so export database-only edits first.
"""
from __future__ import annotations
import argparse
import json
import shutil
import sqlite3
from pathlib import Path

SCHEMA = '''
CREATE TABLE technology_sections (
 id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE,
 fields_json TEXT NOT NULL, stages_json TEXT NOT NULL
);
CREATE TABLE technologies (
 id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE,
 section_id TEXT NOT NULL REFERENCES technology_sections(id),
 kind TEXT NOT NULL, what TEXT NOT NULL, edge TEXT NOT NULL,
 best_for TEXT NOT NULL, watch_out TEXT NOT NULL,
 runtime TEXT NOT NULL, access TEXT NOT NULL, execution TEXT NOT NULL,
 evidence_status TEXT NOT NULL, reviewed_on TEXT,
 lifecycle TEXT NOT NULL, comparison_basis TEXT NOT NULL,
 complexity TEXT NOT NULL, test_before_choice TEXT NOT NULL,
 notes TEXT NOT NULL DEFAULT ''
);
CREATE TABLE technology_sources (
 technology_id TEXT NOT NULL REFERENCES technologies(id),
 url TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'primary',
 review_status TEXT NOT NULL, reviewed_on TEXT,
 PRIMARY KEY(technology_id,url)
);
CREATE TABLE technology_tags (
 technology_id TEXT NOT NULL REFERENCES technologies(id),
 tag TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('field','workflow','keyword')),
 PRIMARY KEY(technology_id,tag,kind)
);
CREATE TABLE technology_concepts (
 technology_id TEXT NOT NULL REFERENCES technologies(id),
 term_id TEXT NOT NULL REFERENCES terms(id),
 PRIMARY KEY(technology_id,term_id)
);
CREATE TABLE technology_alternatives (
 technology_id TEXT NOT NULL REFERENCES technologies(id),
 alternative_name TEXT NOT NULL,
 alternative_id TEXT REFERENCES technologies(id),
 PRIMARY KEY(technology_id,alternative_name),
 CHECK(technology_id <> alternative_id)
);
CREATE TABLE playbooks (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, problem TEXT NOT NULL,
 rationale TEXT NOT NULL, first_step TEXT NOT NULL,
 validation TEXT NOT NULL, caveat TEXT NOT NULL, status TEXT NOT NULL
);
CREATE TABLE playbook_technologies (
 playbook_id TEXT NOT NULL REFERENCES playbooks(id),
 technology_id TEXT NOT NULL REFERENCES technologies(id),
 position INTEGER NOT NULL,
 PRIMARY KEY(playbook_id,technology_id)
);
CREATE TABLE playbook_tags (
 playbook_id TEXT NOT NULL REFERENCES playbooks(id),
 tag TEXT NOT NULL, PRIMARY KEY(playbook_id,tag)
);
CREATE INDEX idx_technology_section ON technologies(section_id);
CREATE INDEX idx_technology_tag ON technology_tags(tag,kind);
CREATE INDEX idx_technology_term ON technology_concepts(term_id);
CREATE VIEW technology_profiles AS
 SELECT t.*,s.name AS section,p.url AS primary_reference
 FROM technologies AS t
 JOIN technology_sections AS s ON s.id=t.section_id
 LEFT JOIN technology_sources AS p ON p.technology_id=t.id AND p.role='primary';
CREATE VIRTUAL TABLE technology_fts USING fts5(
 technology_id UNINDEXED, name, what, edge, best_for, watch_out, keywords,
 tokenize='unicode61 remove_diacritics 2'
);
'''

def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=None)
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    source=root/'dictionary'/'ml_dictionary.sqlite'
    if not source.is_file():
        raise SystemExit(f'Missing preserved dictionary database: {source}')
    techs=[json.loads(line) for line in (root/'technologies.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
    sections=json.loads((root/'sections.json').read_text(encoding='utf-8'))
    playbooks=json.loads((root/'playbooks.json').read_text(encoding='utf-8'))
    names={t['name'].casefold():t['id'] for t in techs}
    if len(names)!=len(techs) or len({t['id'] for t in techs})!=len(techs):
        raise SystemExit('Duplicate technology name or ID.')
    output=args.output or root/'ai_technology_hub.sqlite'
    output.parent.mkdir(parents=True,exist_ok=True)
    temporary=output.with_suffix('.building.sqlite')
    if temporary.exists(): temporary.unlink()
    shutil.copy2(source,temporary)
    conn=sqlite3.connect(temporary)
    conn.execute('PRAGMA foreign_keys=ON')
    try:
        conn.executescript(SCHEMA)
        with conn:
            for s in sections:
                conn.execute('INSERT INTO technology_sections VALUES (?,?,?,?)',
                    (s['name'].split(' · ')[0],s['name'],json.dumps(s['tags']),json.dumps(s['stages'])))
            for t in techs:
                vals=[t['id'],t['name'],t['section'].split(' · ')[0]]+[t[k] for k in ['kind','what','edge','best_for','watch_out','runtime','access','execution','evidence_status']]+[t['reviewed_on'] or None]+[t[k] for k in ['lifecycle','comparison_basis','complexity','test_before_choice','notes']]
                conn.execute('INSERT INTO technologies VALUES ('+','.join('?' for _ in vals)+')',vals)
            for t in techs:
                conn.execute('INSERT INTO technology_sources VALUES (?,?,?,?,?)',
                    (t['id'],t['source_url'],'primary',t['evidence_status'],t['reviewed_on'] or None))
                for field,kind in [('tags','field'),('stages','workflow'),('keywords','keyword')]:
                    conn.executemany('INSERT INTO technology_tags VALUES (?,?,?)',[(t['id'],tag,kind) for tag in dict.fromkeys(t[field])])
                conn.executemany('INSERT INTO technology_concepts VALUES (?,?)',[(t['id'],tid) for tid in t['concept_ids']])
                for name in t['alternatives']:
                    conn.execute('INSERT INTO technology_alternatives VALUES (?,?,?)',(t['id'],name,names.get(name.casefold())))
                words=' '.join(t['keywords']+t['tags']+t['stages']+t['linked_concepts']+[t['section'],t['runtime'],t['execution']])
                conn.execute('INSERT INTO technology_fts VALUES (?,?,?,?,?,?,?)',(t['id'],t['name'],t['what'],t['edge'],t['best_for'],t['watch_out'],words))
            for p in playbooks:
                conn.execute('INSERT INTO playbooks VALUES (?,?,?,?,?,?,?,?)',tuple(p[k] for k in ['id','title','problem','rationale','first_step','validation','caveat','status']))
                conn.executemany('INSERT INTO playbook_technologies VALUES (?,?,?)',[(p['id'],tid,i+1) for i,tid in enumerate(p['technology_ids'])])
                conn.executemany('INSERT INTO playbook_tags VALUES (?,?)',[(p['id'],tag) for tag in p['tags']])
            for key,value in [('hub_edition','2.0'),('hub_assembled_on','2026-11-01'),('technology_count',str(len(techs))),('hub_scope','Curated snapshot; editorial fit judgments, not benchmark rankings; no automatic refresh')]:
                conn.execute('INSERT OR REPLACE INTO metadata VALUES (?,?)',(key,value))
        bad=conn.execute('PRAGMA foreign_key_check').fetchall()
        integrity=conn.execute('PRAGMA integrity_check').fetchone()[0]
        if bad or integrity!='ok': raise RuntimeError(f'Integrity failure: {integrity}; foreign keys: {bad}')
        conn.close()
        temporary.replace(output)
        print(f'Built {output} with {len(techs)} technologies and {len(playbooks)} playbooks.')
    except Exception:
        conn.close()
        if temporary.exists(): temporary.unlink()
        raise
if __name__=='__main__':
    main()
