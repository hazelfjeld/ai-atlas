-- Technology search (FTS5 query syntax; editorial fit, not performance ranking).
SELECT t.name, t.section, t.edge, t.watch_out, t.primary_reference
FROM technology_fts AS f
JOIN technology_profiles AS t ON t.id=f.technology_id
WHERE technology_fts MATCH 'quantization'
ORDER BY bm25(technology_fts)
LIMIT 15;

-- Find local/self-hosted technologies tagged for LLMs.
SELECT t.name,t.best_for,t.test_before_choice
FROM technologies AS t
JOIN technology_tags AS tag ON tag.technology_id=t.id
WHERE t.execution='Local / self-hosted' AND tag.kind='field' AND tag.tag='LLM'
ORDER BY t.name;

-- Look up the dictionary concepts behind a technology.
SELECT t.name,c.term,c.definition
FROM technology_concepts AS link
JOIN technologies AS t ON t.id=link.technology_id
JOIN terms AS c ON c.id=link.term_id
WHERE t.name='vLLM'
ORDER BY c.term;

-- Alternatives: a NULL ID means the named alternative is outside this edition.
SELECT t.name,a.alternative_name,a.alternative_id
FROM technology_alternatives AS a
JOIN technologies AS t ON t.id=a.technology_id
WHERE t.name='pgvector';

-- Source review status: do not interpret a reference link as verification.
SELECT evidence_status,COUNT(*) AS profiles
FROM technologies GROUP BY evidence_status;

-- Inspect lifecycle cautions before adopting a tool.
SELECT name,lifecycle,watch_out FROM technologies
WHERE lifecycle<>'Not independently audited' ORDER BY name;

-- A suggested private/local document-QA starting configuration.
SELECT p.title,pt.position,t.name,t.watch_out
FROM playbooks AS p
JOIN playbook_technologies AS pt ON pt.playbook_id=p.id
JOIN technologies AS t ON t.id=pt.technology_id
WHERE p.id='PB-03' ORDER BY pt.position;

-- The complete original concept dictionary is still available.
SELECT term,definition FROM terms
WHERE lower(term) LIKE '%distillation%' ORDER BY term;
