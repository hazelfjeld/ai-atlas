#!/usr/bin/env python3
"""Rebuild the standalone offline HTML from the included data; no network access."""
from pathlib import Path
from collections import Counter
import argparse
import json

def main() -> None:
    root=Path(__file__).resolve().parent
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=root/'AI_Technology_Hub.html')
    args=parser.parse_args()
    def jsonl(name: str) -> list[dict]:
        return [json.loads(line) for line in (root/name).read_text(encoding='utf-8').splitlines() if line.strip()]
    techs=jsonl('technologies.jsonl')
    terms=jsonl('terms.jsonl')
    sections=json.loads((root/'sections.json').read_text(encoding='utf-8'))
    playbooks=json.loads((root/'playbooks.json').read_text(encoding='utf-8'))
    data={'metadata':{'title':'AI technology hub','edition':'2.0','assembled_on':'2026-11-01',
          'technology_count':len(techs),'concept_count':len(terms),'section_count':len(sections),'playbook_count':len(playbooks),
          'review_counts':dict(Counter(t['evidence_status'] for t in techs)),
          'scope':'Broad curated snapshot, not an exhaustive inventory. Advantages and playbooks are conditional editorial judgments, not head-to-head benchmark results.',
          'refresh':'No automatic refresh. Exports are independent snapshots.'},
          'technologies':techs,'terms':terms,'sections':sections,'playbooks':playbooks}
    payload=json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    template=(root/'hub_template.html').read_text(encoding='utf-8')
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(template.replace('__HUB_DATA__',payload),encoding='utf-8')
    print(f'Built {args.output}')
if __name__=='__main__':
    main()
