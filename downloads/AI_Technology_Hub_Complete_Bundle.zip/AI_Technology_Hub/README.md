# AI Technology Hub — Edition 2.0

Assembled November 1, 2026. A curated, expandable reference and technology-selection aid, not an exhaustive inventory, benchmark leaderboard or live service.

## Contents

- **300 technology profiles** across **31 sections**.
- **1,345 preserved concept records** from the original ML / DL / SLM / LLM dictionary.
- **20 problem playbooks**, each with candidate tools, rationale, a first practical step, a validation plan and a caveat.
- **685 technology-to-concept links** plus the original dictionary's **2,691 concept relationships**.
- An interactive offline browser hub, a 16-sheet workbook, normalized SQLite with full-text search, CSV/JSONL exports, source-review register and rebuild scripts.

Technology profiles overlap concept records. Do not add the counts and call the result unique technologies.

## Start here

Open `AI_Technology_Hub.html` in a current desktop browser. The entire interface and dataset are inside that file. No account, API key, installation or hosted server is required. Some mobile file-preview applications do not execute JavaScript; a desktop browser is the most reliable option.

The browser hub supports literal keyword search, section/execution/evidence filters, full technology details, up to three side-by-side comparisons, the original concept dictionary and problem playbooks. Stars and notes are saved in browser local storage when available. Export saved notes for a portable backup; browser storage can be cleared, isolated or unavailable. The app falls back to session-only notes with a warning. Export matching records produces a JSON snapshot of the filtered records. There is no notes-import interface in this edition.

There are no external scripts, fonts, telemetry requests, model calls or background updates. Clicking an official reference opens that website. The hub does not install or execute the technologies it describes.

## Workbook

`AI_Technology_Hub.xlsx` retains the original seven sheets and adds nine sheets:

- Tech Search: literal keyword search with exact section and execution filters; previews 20 matches.
- Tech Profile: choose a technology in the yellow cell to display its full profile.
- Compare: choose three technologies in the yellow cells; no fabricated winner score.
- Tech Catalog: the full filterable technology table, including references and editable notes.
- Section Guide: the 31-category index. Copy a Browse destination into Excel's Name Box to jump to a block.
- Browse Sections: all profiles arranged into 31 distinct section blocks.
- Playbooks: 20 editorial starting configurations.
- Tech Evidence: every profile's source, review status and lifecycle note.
- Hub Guide: scope, methodology, limitations and editing instructions.

The original sheets are Start Here, Search, Dictionary, Topic Map, Tags, Learning Paths and Sources. Start Here is now the hub cover; the original concept data is retained. Yellow cells are intended for inputs or notes. Search helper columns and formulas should not be overwritten. Technology search is not a semantic recommendation model. Filter the catalog to see all matches.

Adding rows requires extending tables, formulas, selectors, summaries and cross-links. Technology IDs are stable within this edition: append new IDs rather than renumbering existing profiles when sorting.

## What qualifies as an edge

A profile names a concrete, conditional reason to choose the technology: a useful capability, deployment fit, integration with an existing system, data locality, control, memory behavior, workflow simplicity or specialization. It also states a limitation or situation where an alternative can be more suitable.

Descriptions and sources concern the technology. Advantages, best-fit problems, tradeoffs, complexity levels, validation suggestions and playbooks are editorial synthesis. No head-to-head performance benchmark or end-to-end playbook deployment was performed. A playbook's tools may be alternatives rather than a list to install together.

## Evidence and maintenance

All 300 profiles include an official reference URL, but those links have different review levels:

- **33: Core capability checked in primary documentation.** The core mechanism was checked during this pass. This is not an independent audit of every field or a benchmark proving superiority.
- **22: Official page located/opened — partial review.** An official page was located or opened, but the profile was not fully validated.
- **245: Reference link only — not reviewed this edition.** A reading pointer, not a verification claim.

The profile's review date is populated only for the first two categories. `Not independently audited` in the lifecycle field does not mean a project is active. Explicit warnings flag selected archive, maintenance, successor and license distinctions. Broad distribution labels do not replace the exact release's license, model/data terms, dependencies, service policies or professional legal review where needed.

The original dictionary has its own source registry and review labels in `dictionary/sources.csv`. Its definitions were not all re-audited in this technology expansion.

No automatic refresh or recurring task is configured. Recheck current releases, hardware support, pricing, security requirements and terms before a material adoption decision. This edition deliberately avoids guessed price tables and universal performance rankings.

## Database and files

- `ai_technology_hub.sqlite`: original dictionary tables plus the technology layer.
- `technologies.jsonl`: complete structured profiles; arrays retain separate tags and relationships.
- `technologies.csv`: spreadsheet-friendly flat export; list-valued fields use semicolon separators.
- `terms.jsonl`: the preserved dictionary records used in the browser hub.
- `technology_sources.csv`: explicit reference/review/lifecycle register.
- `sections.json`, `playbooks.json`: category metadata and editorial configurations.
- `schema.sql`, `examples.sql`: schema reference and eight tested queries.
- `dictionary/`: the complete original dictionary bundle, unchanged.
- `validation/`: browser, workbook and database validation results.
- `build_database.py`, `build_html.py`, `hub_template.html`: dependency-free rebuild tools/source.

The technology layer uses separate tables for sections, sources, field/workflow/keyword tags, concept links, alternatives and playbook membership. Alternative names outside this edition retain a NULL alternative ID; no nonexistent technology row is invented. `technology_profiles` is a convenient joined view. `technology_fts` supplies lexical FTS5 search; its scores are text relevance, not product quality.

### Query from Python

```python
import sqlite3

with sqlite3.connect('ai_technology_hub.sqlite') as db:
    rows = db.execute('''
        SELECT t.name, t.edge, t.watch_out
        FROM technology_fts AS f
        JOIN technologies AS t ON t.id=f.technology_id
        WHERE technology_fts MATCH ?
        ORDER BY bm25(technology_fts)
        LIMIT 10
    ''', ('quantization',)).fetchall()
    for row in rows:
        print(row)
```

FTS5 uses its own query grammar. Validate or escape arbitrary user search input before incorporating it into an application; SQL parameter binding is necessary but does not turn every arbitrary string into a valid FTS query.

### Rebuild after edits

Python 3.10+ with standard-library SQLite compiled with FTS5 is required. No third-party Python packages or network calls are used by these two scripts.

```sh
python build_database.py
python build_html.py
```

`build_database.py` replaces the database from the included original `dictionary/ml_dictionary.sqlite`, technology JSONL, sections and playbooks. Export database-only changes before rebuilding. The separate `terms.jsonl` controls the HTML dictionary; changing it alone does not mutate the preserved dictionary database. `build_html.py` rebuilds the standalone HTML. Neither script updates the XLSX or the flat CSV files. Adjust edition/date labels when producing a later verified edition.

These are independent snapshots, not synchronized views. Edits in the XLSX, SQLite, HTML local notes or JSONL do not automatically propagate elsewhere. Rebuild the affected exports deliberately. Direct database edits do not automatically rebuild the technology full-text index; use the rebuild workflow or maintain the index explicitly in your own application.

## Validation performed

The workbook's technology search was tested for a keyword match, an exact category match and a zero-match query; results agreed with direct data checks. The original dictionary's names, definitions and IDs were compared exactly. A formula scan found no listed spreadsheet errors. Workbook cover/profile views were rendered for visual review.

The HTML was exercised in Chromium with desktop and phone viewport sizes: keyword and section filters, details, note fallback, comparison, dictionary search, playbooks and the evidence page. There were no JavaScript errors, no background network requests and no horizontal overflow at a 390-pixel viewport. The container's browser blocks direct file navigation, so the test injected the same local HTML content rather than navigating to the file. Durable browser-local storage was not verified in that sandbox; the explicit session-only fallback was verified. This is not an exhaustive cross-browser or accessibility audit.

The SQLite database passed integrity and foreign-key checks. All eight example queries executed. These checks validate the artifacts' structure and behavior—not the empirical superiority of the listed technologies.
