-- Run with SQLite built with FTS5.
PRAGMA foreign_keys = ON;

-- Search exact words / phrases across terms, aliases, definitions, tags and examples.
SELECT term_id, term
FROM terms_fts
WHERE terms_fts MATCH '"reward hacking"'
ORDER BY bm25(terms_fts)
LIMIT 20;

-- Exact field tagging: ML does not mean SLM or LLM.
SELECT t.id, t.term, t.definition, t.level
FROM terms t JOIN term_tags tt ON tt.term_id = t.id
WHERE tt.tag_name = 'SLM' AND tt.tag_kind = 'field'
ORDER BY t.term;

-- Related concepts for knowledge distillation.
SELECT target.id, target.term, target.definition
FROM terms source
JOIN relationships r ON r.from_id = source.id
JOIN terms target ON target.id = r.to_id
WHERE source.term = 'Knowledge distillation'
ORDER BY target.term;

-- Resolve an acronym without pretending it is always unambiguous.
SELECT t.id, t.term, t.definition
FROM aliases a JOIN terms t ON t.id = a.term_id
WHERE a.alias = 'LoRA' COLLATE NOCASE;

-- Browse a learning route in order.
SELECT p.step, t.term, p.rationale
FROM learning_paths p JOIN terms t ON t.id = p.term_id
WHERE p.path = 'AI safety and interpretability'
ORDER BY p.step;

-- References associated with a concept.
SELECT s.title, s.url, s.review_status
FROM terms t JOIN term_sources ts ON ts.term_id = t.id
JOIN sources s ON s.id = ts.source_id
WHERE t.term = 'Knowledge distillation'
ORDER BY ts.position;
