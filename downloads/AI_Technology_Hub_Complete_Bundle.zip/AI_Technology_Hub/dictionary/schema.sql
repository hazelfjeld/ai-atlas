PRAGMA foreign_keys=ON;
CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE topics (name TEXT PRIMARY KEY, description TEXT NOT NULL);
CREATE TABLE terms (
 id TEXT PRIMARY KEY, term TEXT NOT NULL UNIQUE, definition TEXT NOT NULL,
 topic TEXT NOT NULL REFERENCES topics(name), level TEXT NOT NULL,
 example TEXT NOT NULL, caveat TEXT NOT NULL, reference_url TEXT NOT NULL,
 notes TEXT NOT NULL DEFAULT ''
);
CREATE TABLE aliases (
 term_id TEXT NOT NULL REFERENCES terms(id), alias TEXT NOT NULL,
 PRIMARY KEY(term_id,alias)
);
CREATE TABLE tags (
 name TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('field','workflow')),
 description TEXT NOT NULL, PRIMARY KEY(name,kind)
);
CREATE TABLE term_tags (
 term_id TEXT NOT NULL REFERENCES terms(id), tag_name TEXT NOT NULL,
 tag_kind TEXT NOT NULL, PRIMARY KEY(term_id,tag_name,tag_kind),
 FOREIGN KEY(tag_name,tag_kind) REFERENCES tags(name,kind)
);
CREATE TABLE sources (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, url TEXT NOT NULL,
 kind TEXT NOT NULL, review_status TEXT NOT NULL
);
CREATE TABLE term_sources (
 term_id TEXT NOT NULL REFERENCES terms(id), source_id TEXT NOT NULL REFERENCES sources(id),
 position INTEGER NOT NULL, PRIMARY KEY(term_id,source_id)
);
CREATE TABLE relationships (
 from_id TEXT NOT NULL REFERENCES terms(id), to_id TEXT NOT NULL REFERENCES terms(id),
 relation_type TEXT NOT NULL DEFAULT 'related',
 PRIMARY KEY(from_id,to_id,relation_type), CHECK(from_id<>to_id)
);
CREATE TABLE learning_paths (
 path TEXT NOT NULL, step INTEGER NOT NULL, term_id TEXT NOT NULL REFERENCES terms(id),
 rationale TEXT NOT NULL, PRIMARY KEY(path,step)
);
CREATE INDEX idx_terms_topic ON terms(topic);
CREATE INDEX idx_terms_level ON terms(level);
CREATE INDEX idx_tags_lookup ON term_tags(tag_name,tag_kind);
CREATE INDEX idx_alias_lookup ON aliases(alias COLLATE NOCASE);
CREATE INDEX idx_related_target ON relationships(to_id);
CREATE VIRTUAL TABLE terms_fts USING fts5(
 term_id UNINDEXED, term, aliases, definition, tags, workflow, topic, example, caveat,
 tokenize='unicode61'
);
