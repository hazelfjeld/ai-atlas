# ML / DL / SLM / LLM Dictionary — Edition 1.0

Assembled: 2026-11-01
Contents: 1,345 distinct concepts; 34 primary topics; 21 field tags; 86 reference sources.
Related-term links: 2,691.
This is a broad, finite, editable reference, not a claim to include every term in an evolving field.

## Files
- terms.csv: UTF-8 with BOM, one concept per row. Multi-valued fields use semicolon + space.
- terms.jsonl: UTF-8, one JSON object per line. Aliases, tags, workflow stages, related names, related IDs, and source IDs are arrays.
- ml_dictionary.sqlite: normalized relational database plus an FTS5 full-text search index.
- sources.csv: primary-source registry, with review-status labels.
- schema.sql: database schema, indexes, and FTS definition.
- examples.sql: tested queries for search, exact field tags, and related concepts.

The separately supplied Excel workbook contains Start Here, Search, Dictionary, Topic Map, Tags, Learning Paths, and Sources.
The Excel Search sheet has editable keyword input B5 and field tag D5. It returns the first 30 alphabetical matches.
Clear the keyword to browse a field; use the Dictionary filters to inspect all matching rows.
Search is a case-insensitive substring match, not a semantic search engine. Excel SEARCH also recognizes its standard wildcard syntax.
The SQLite full-text index uses word tokenization; its results therefore differ from the spreadsheet's substring results.

## Record fields
id: stable identifier within this edition. Preserve existing IDs when extending the database.
term: canonical concept name.
aliases: acronyms and alternative names. These do not count as additional concepts.
definition: original, concise explanatory definition.
tags: nonexclusive fields where the concept is generally used.
topic: one primary organizing topic.
stages: nonexclusive workflow stages.
level: editorial Foundational / Intermediate / Advanced guidance, not a formal prerequisite system.
example: one illustrative application, not a recommendation that it always works.
related: names of other included concepts.
related_ids: corresponding IDs in JSONL and normalized SQLite relationships.
caveat: a common confusion, assumption, or limitation.
source_ids: identifiers in the source registry, in reference order.
reference_url: the first listed primary reference for convenience.
notes: editable personal notes, initially empty.

## Sources and scope
Definitions and examples are original summaries. URLs point to documentation, research papers, and author-hosted reference material.
Consulted: the resource was surfaced or opened during preparation.
Reference link: provided as a primary further-reading pointer but not separately checked.
These labels are not a claim that every statement in every row has been independently audited.
Some general references cover a topic rather than an exact named subsection. Websites and software APIs can change.
No benchmark scores, model rankings, prices, or universal SLM/LLM size thresholds are asserted.

Fields overlap. Missing a usage tag does not mean a concept cannot be used in that setting.
Aliases can be ambiguous: for example, an acronym may have different meanings across fields.
Related links are directional reading suggestions, not proofs of synonymy, causality, or prerequisite relations.
Use the definitions and source context to disambiguate terms.

## Workbook editing
Yellow Search inputs and Dictionary My notes cells are intended for editing.
Column O of Dictionary is a numeric search helper; preserve its formulas.
When appending entries, extend the table and all formula ranges, including search, topics, source summaries, and learning-path lookups.
Field/workflow/source summary formulas enumerate this edition's canonical combinations.
When adding a new combination of tags or source IDs, extend the corresponding summary formulas too.
No macros, external data connections, or automatic refresh are included.

## Database editing
SQLite foreign keys must be enabled per connection:
PRAGMA foreign_keys = ON;

The FTS5 table is a populated search snapshot, not an automatically synchronized external-content index.
After editing a concept, update its matching terms_fts row or rebuild the FTS rows from the relational tables.
Keep normalized aliases, term_tags, term_sources, and relationships consistent with the concept.
IDs are edition-stable; do not regenerate all IDs just because the alphabetical order changes.

The CSV, JSONL, SQLite, and Excel outputs are snapshots. Editing one does not automatically update the others.

## Integrity checks performed
- Duplicate canonical-name check.
- Required definition, example, caveat, and source-ID checks.
- Every related-term link resolves to an included concept.
- Spreadsheet search checked against an independent Python implementation for ML, SLM, LoRA, no matches, and the default query.
- SQLite integrity_check and foreign_key_check.
- SQLite term and full-text row counts match the dictionary.
- A full-text query for reward hacking returns matching records.
